﻿
$(document).on("pagecreate", "#mapa", function (event) {
    GetMap();
});
function conversorGrados(grados, minutos, segundos, direccion) {
    var dd = Number(grados) + Number(minutos) / 60 + Number(segundos) / (60 * 60);
    if (direccion == 'S' || direccion == 'W') {
        dd = dd * (-1);
    }
    return dd;
}

function GetMap() {
    console.log("entramos a la funcion");
    var datos;
    var lati;
    var long;
    var key = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhc2xhbmFkaWRhczk4QGdtYWlsLmNvbSIsImp0aSI6IjVmNGE3YTUyLWZjZWItNGNiZS05YzVjLTJiZDQ5OTY2ZDBhMiIsImlzcyI6IkFFTUVUIiwiaWF0IjoxNTM3ODk0NjY3LCJ1c2VySWQiOiI1ZjRhN2E1Mi1mY2ViLTRjYmUtOWM1Yy0yYmQ0OTk2NmQwYTIiLCJyb2xlIjoiIn0.-UCBvHjtvk9X-Kh-zcQ7wyk4M9yobpx1773wqb2tV6k';
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "https://opendata.aemet.es/opendata/api/valores/climatologicos/inventarioestaciones/todasestaciones?api_key=" + key,
        "method": "GET",
        "headers": {
            "cache-control": "no-cache"
        }
    }
    var map = new Microsoft.Maps.Map('#myMap', {
        credentials: 'AgtwDG8Wn1X-qDVMkhqYuDHp9yvg1VLpAqwRM2mVdomu6tIkukTPHtdzG0UVOMlL'
    });
    console.log("hemosintroducido la llave");

    $.ajax(settings).done(function (response) {
        console.log("esto es lo que hay dentro" + response.datos);

        var settings2 = {
            "async": true,
            "crossDomain": true,
            "url": response.datos,
            "method": "GET",
            "headers": {
                "cache-control": "no-cache"
            }
        }
        $.ajax(settings2).done(function (response2) {
            $("#loader3").fadeOut("slow");
            //Parseo a objeto para filtrar y meter en datatable
            datos = JSON.parse(response2);
            //Filtro los municipios que contengan "san vicente"
            datos.forEach(function (entry) {
                lati = entry.latitud;
                long = entry.longitud;

                ladeg = lati.substring(0, 2);
                lamin = lati.substring(2, 4);
                lasec = lati.substring(4, 6);
                ladir = lati.substring(6, 7);
                latitud = conversorGrados(ladeg, lamin, lasec, ladir);

                lodeg = long.substring(0, 2);
                lomin = long.substring(2, 4);
                losec = long.substring(4, 6);
                lodir = long.substring(6, 7);
                longitud = conversorGrados(lodeg, lomin, losec, lodir);

                var locMadrid = new Microsoft.Maps.Location(
                    '40.4893538',
                    '-3.6827461'); 


                var loc = new Microsoft.Maps.Location(
                    latitud,
                    longitud); 

                var pin = new Microsoft.Maps.Pushpin(loc, {
                    icon: 'https://www.bingmapsportal.com/Content/images/poi_custom.png',
                    anchor: new Microsoft.Maps.Point(12, 39)
                });

                var infobox = new Microsoft.Maps.Infobox(loc, { visible: false, autoAlignment: true });
                infobox.setMap(map);

                pin.metadata = {
                    title: entry.nombre,
                    description: 'Altitud: ' + entry.altitud + ' metros'
                };
                Microsoft.Maps.Events.addHandler(pin, 'click', function (args) {
                    infobox.setOptions({
                        location: args.target.getLocation(),
                        title: args.target.metadata.title,
                        description: args.target.metadata.description,
                        visible: true
                    });
                });


                map.entities.push(pin);
                //Center the map on the user's location.
                map.setView({ center: locMadrid, zoom: 5 });
            });
        });

 /*
            var loc = new Microsoft.Maps.Location(
                '40.7127753',
                '-74.0059728');
            var pushpin = new Microsoft.Maps.Pushpin(loc, {
                icon: 'https://www.bingmapsportal.com/Content/images/poi_custom.png',
                anchor: new Microsoft.Maps.Point(12, 39)
            });
            map.entities.push(pushpin);
            //Center the map on the user's location.
            map.setView({ center: loc, zoom: 15 });
        */

    });


/*
    //Request the user's location
    navigator.geolocation.getCurrentPosition(function (position) {
        console.log("entramos a la funcion geolocalizacion");
        var loc = new Microsoft.Maps.Location(
            position.coords.latitude,
            position.coords.longitude);
        //Add a pushpin at the user's location.
        var pushpin = new Microsoft.Maps.Pushpin(loc, {
            icon: 'https://www.bingmapsportal.com/Content/images/poi_custom.png',
            anchor: new Microsoft.Maps.Point(12, 39)
        });
        map.entities.push(pushpin);
        //Center the map on the user's location.
        map.setView({ center: loc, zoom: 15 });
    });

 */

}

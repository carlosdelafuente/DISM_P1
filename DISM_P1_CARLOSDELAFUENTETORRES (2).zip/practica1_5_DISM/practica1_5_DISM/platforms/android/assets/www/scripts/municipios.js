﻿
$(document).on("pagecreate", "#municipios", function (event) {
    console.log("entramos en municipiossss");
    InicializarGrid();

});


function InicializarGrid() {
    var datos;
    var datosfiltrados = [];
    var key = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhc2xhbmFkaWRhczk4QGdtYWlsLmNvbSIsImp0aSI6IjVmNGE3YTUyLWZjZWItNGNiZS05YzVjLTJiZDQ5OTY2ZDBhMiIsImlzcyI6IkFFTUVUIiwiaWF0IjoxNTM3ODk0NjY3LCJ1c2VySWQiOiI1ZjRhN2E1Mi1mY2ViLTRjYmUtOWM1Yy0yYmQ0OTk2NmQwYTIiLCJyb2xlIjoiIn0.-UCBvHjtvk9X-Kh-zcQ7wyk4M9yobpx1773wqb2tV6k';
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "https://opendata.aemet.es/opendata/api/maestro/municipios?api_key=" + key,
        "method": "GET",
        "headers": {
            "cache-control": "no-cache"
        }
    }
    $.ajax(settings).done(function (response) {
        var j = 0;
        datos = JSON.parse(response);
        datos.forEach(function (entry) {
            if (entry.num_hab>50000) {
                datosfiltrados[j] = entry;
                j = j + 1;
            }
        });
        console.log("el numeo de itineraciones en municipios es" + j);
        tabla = $('#dataGrid').DataTable({
            responsive: true,
            "data": datosfiltrados,
            "columns": [
                {
                    "data": "nombre"
                },
                {
                    "data": "latitud"
                },
                {
                    "data": "longitud"
                },
                {
                    "data": "num_hab"
                }
            ]
        });
        $("#loader").fadeOut("slow");
    });
}
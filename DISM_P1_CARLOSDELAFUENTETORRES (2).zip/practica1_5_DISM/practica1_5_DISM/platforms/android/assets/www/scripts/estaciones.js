﻿


var latitud;
var longitud;
var latino = '432157N';
var longitino = '082517W';
$(document).on("pagecreate", "#estaciones", function (event) {
    console.log("entramos en estaciones");
    InicializarGrid2();
});
function conversorGrados2(grados, minutos, segundos, direccion) {
    var dd = Number(grados) + Number(minutos) / 60 + Number(segundos) / (60 * 60);
    if (direccion == 'S' || direccion == 'W') {
        dd = dd * (-1);
    }
    return dd;
}
function imprimirMapa(e) {
    console.log(e.parentNode.parentNode.children[1].innerHTML);
    console.log(e.parentNode.parentNode.children[2].innerHTML);

    lati = e.parentNode.parentNode.children[1].innerHTML;
    long = e.parentNode.parentNode.children[2].innerHTML;
    
    ladeg = lati.substring(0, 2);
    lamin = lati.substring(2, 4);
    lasec = lati.substring(4, 6);
    ladir = lati.substring(6, 7);
    latitud = conversorGrados2(ladeg, lamin, lasec, ladir);

    lodeg = long.substring(0, 2);
    lomin = long.substring(2, 4);
    losec = long.substring(4, 6);
    lodir = long.substring(6, 7);
    longitud = conversorGrados2(lodeg, lomin, losec, lodir);

    console.log("estas son las latitudes y longiudes carrectas" + latitud + "," + longitud);
    mostarMensaje(latitud, longitud);
    
}
function mostarMensaje(latitu, longitu) {

    var translucido = document.createElement("DIV");

    translucido.id = 'translucido';
    translucido.style.position = 'fixed';
    translucido.style.width = '100%';
    translucido.style.height = '100%';
    translucido.style.margin = '0';
    translucido.style.top = '0';
    translucido.style.left = '0';
    translucido.style.background = '#FFF';
    translucido.style.opacity = '0.8';
    translucido.style.zIndex = '1';

    var caja = document.createElement("DIV");

    caja.id = 'caja';
    caja.style.position = 'absolute';
    caja.style.width = '360px';
    caja.style.top = '2em';
    caja.style.left = '50%';
    caja.style.background = '#eee';
    caja.style.border = '2px solid black';
    caja.style.transform = 'translate(-50%)';
    caja.style.zIndex = '2';

    var titulo = document.createElement("H2");
    var nodoTitulo = document.createTextNode('MAPA GEOLOCALIZACION');
    titulo.appendChild(nodoTitulo);

    titulo.style.textAlign = 'center';
    titulo.style.background = '#00B119';

    titulo.style.margin = '0';
    titulo.style.padding = '1em';
    titulo.style.fontSize = '2em';

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    var contenedor_mapa = document.createElement("DIV");
    contenedor_mapa.id = 'myMapEspecifico';
    contenedor_mapa.style.width = '358px';
    contenedor_mapa.style.height = '358px';
    contenedor_mapa.style.margin = '0';
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    var boton = document.createElement("BUTTON");
    var nodoBoton = document.createTextNode("Volver");
    boton.appendChild(nodoBoton);

    boton.id = 'aceptar';
    boton.style.display = 'block';
    boton.style.margin = 'auto';
    boton.style.marginBottom = '1.5em';
    boton.style.margin = '1.5em';

    boton.onclick = function () {
        var caja = document.getElementById('caja');
        document.body.removeChild(caja);
        var translucido = document.getElementById('translucido');
        document.body.removeChild(translucido);
    }

    caja.appendChild(titulo);
    caja.appendChild(contenedor_mapa);
    caja.appendChild(boton);


    document.body.appendChild(translucido);
    document.body.appendChild(caja);

    boton.focus();
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////7
    var datos;
    var lati;
    var long;
    var key = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhc2xhbmFkaWRhczk4QGdtYWlsLmNvbSIsImp0aSI6IjVmNGE3YTUyLWZjZWItNGNiZS05YzVjLTJiZDQ5OTY2ZDBhMiIsImlzcyI6IkFFTUVUIiwiaWF0IjoxNTM3ODk0NjY3LCJ1c2VySWQiOiI1ZjRhN2E1Mi1mY2ViLTRjYmUtOWM1Yy0yYmQ0OTk2NmQwYTIiLCJyb2xlIjoiIn0.-UCBvHjtvk9X-Kh-zcQ7wyk4M9yobpx1773wqb2tV6k';
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "https://opendata.aemet.es/opendata/api/valores/climatologicos/inventarioestaciones/todasestaciones?api_key=" + key,
        "method": "GET",
        "headers": {
            "cache-control": "no-cache"
        }
    }
    var map = new Microsoft.Maps.Map('#myMapEspecifico', {
        credentials: 'AgtwDG8Wn1X-qDVMkhqYuDHp9yvg1VLpAqwRM2mVdomu6tIkukTPHtdzG0UVOMlL'
    });

    $.ajax(settings).done(function (response) {
        console.log("esto es lo que hay dentro" + response.datos);

        var settings2 = {
            "async": true,
            "crossDomain": true,
            "url": response.datos,
            "method": "GET",
            "headers": {
                "cache-control": "no-cache"
            }
        }
        $.ajax(settings2).done(function (response2) {
            //Parseo a objeto para filtrar y meter en datatable
            datos = JSON.parse(response2);
            //Filtro los municipios que contengan "san vicente"
            datos.forEach(function (entry) {
                var loc = new Microsoft.Maps.Location(
                    latitud,
                    longitud);

                var pin = new Microsoft.Maps.Pushpin(loc, {
                    icon: 'https://www.bingmapsportal.com/Content/images/poi_custom.png',
                    anchor: new Microsoft.Maps.Point(12, 39)
                });

                var infobox = new Microsoft.Maps.Infobox(loc, { visible: false, autoAlignment: true });
                infobox.setMap(map);

                pin.metadata = {
                    title: entry.nombre,
                    description: 'Altitud: ' + entry.altitud + ' metros'
                };
                Microsoft.Maps.Events.addHandler(pin, 'click', function (args) {
                    infobox.setOptions({
                        location: args.target.getLocation(),
                        title: args.target.metadata.title,
                        description: args.target.metadata.description,
                        visible: true
                    });
                });

                map.entities.push(pin);
                map.setView({ center: loc, zoom: 5 });
            });
        });
    });

///////////////////////////////////////////////////////////////////////////////////////////////////////////////


}

function InicializarGrid2() {
    var datos;
    var datosfiltrados = [];
    var key = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhc2xhbmFkaWRhczk4QGdtYWlsLmNvbSIsImp0aSI6IjVmNGE3YTUyLWZjZWItNGNiZS05YzVjLTJiZDQ5OTY2ZDBhMiIsImlzcyI6IkFFTUVUIiwiaWF0IjoxNTM3ODk0NjY3LCJ1c2VySWQiOiI1ZjRhN2E1Mi1mY2ViLTRjYmUtOWM1Yy0yYmQ0OTk2NmQwYTIiLCJyb2xlIjoiIn0.-UCBvHjtvk9X-Kh-zcQ7wyk4M9yobpx1773wqb2tV6k';
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "https://opendata.aemet.es/opendata/api/valores/climatologicos/inventarioestaciones/todasestaciones?api_key=" + key,
        "method": "GET",
        "headers": {
            "cache-control": "no-cache"
        }
    }
    $.ajax(settings).done(function (response) {
        var settings2 = {
            "async": true,
            "crossDomain": true,
            "url": response.datos + "?api key=" + key,
            "method": "GET",
            "headers": {
                "cache-control": "no-cache"
            }
        }
        $.ajax(settings2).done(function (response) {
            var k = 0;
            datos = JSON.parse(response);
            datos.forEach(function (entry) {
                    datosfiltrados[k] = entry;
                    k = k + 1;
            });
            console.log(datosfiltrados);
            console.log(datosfiltrados[5]);
            var i = 0;
            tabla = $('#dataGrid2').DataTable({
                "scrollX": true,
                "data": datosfiltrados,
                "columns": [
                    {
                        "data": "nombre"
                    },
                    {
                        "data": "latitud"
                    },
                    {
                        "data": "longitud"
                    },
                    {
                        "data": "indicativo"
                    },
                    {
                        "defaultContent": "<button onclick='imprimirMapa(this)'>Mapa</button>"
                    }
                ]

            });
            $("#loader2").fadeOut("slow");
        });
    });

}
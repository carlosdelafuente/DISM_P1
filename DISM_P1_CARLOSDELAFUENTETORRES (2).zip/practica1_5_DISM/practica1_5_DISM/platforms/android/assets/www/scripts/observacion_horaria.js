﻿
$(document).on("pagecreate", "#observacion_horaria", function (event) {
    console.log("entramos en observacion horaria");
    InicializarGrid3();
});
function imprimirIdema(e) {

    idema = e.parentNode.parentNode.children[1].innerHTML;

    console.log("el idemaaaaaaa: " + idema);
    mostarUltimas24(idema);
}
function mostarUltimas24(idem2) {

    var translucido = document.createElement("DIV");

    translucido.id = 'translucido';
    translucido.style.position = 'fixed';
    translucido.style.width = '100%';
    translucido.style.height = '100%';
    translucido.style.margin = '0';
    translucido.style.top = '0';
    translucido.style.left = '0';
    translucido.style.background = '#FFF';
    translucido.style.opacity = '0.8';
    translucido.style.zIndex = '1';

    var caja = document.createElement("DIV");

    caja.id = 'caja';
    caja.style.position = 'absolute';
    caja.style.width = '100%';
    caja.style.top = '.5em';
    caja.style.left = '50%';
    caja.style.background = '#eee';
    caja.style.border = '2px solid black';
    caja.style.transform = 'translate(-50%)';
    caja.style.zIndex = '2';

    var titulo = document.createElement("H2");
    var nodoTitulo = document.createTextNode('ÚLTIMAS 24H');
    titulo.appendChild(nodoTitulo);

    titulo.style.textAlign = 'center';
    titulo.style.background = '#00B119';

    titulo.style.margin = '0';
    titulo.style.padding = '1em';
    titulo.style.fontSize = '2em';

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    var contenedor_idema = document.createElement("DIV");
    contenedor_idema.id = 'miIdema';
    contenedor_idema.style.margin = '0';

    var tabla = document.createElement("table");
    tabla.id = 'dataIdema';
    tabla.style.width = '100%';

    var thead = document.createElement("thead");

    var tr = document.createElement("tr");

    var th1 = document.createElement("th");
    var textoth1 = document.createTextNode("Idema");
    th1.appendChild(textoth1);
    var th2 = document.createElement("th");
    var textoth2 = document.createTextNode("Ubicacion");
    th2.appendChild(textoth2);
    var th3 = document.createElement("th");
    var textoth3 = document.createTextNode("Fecha-hora");
    th3.appendChild(textoth3);
    var th4 = document.createElement("th");
    var textoth4 = document.createTextNode("Temperatura");
    th4.appendChild(textoth4);

    tr.appendChild(th1);
    tr.appendChild(th2);
    tr.appendChild(th3);
    tr.appendChild(th4);

    thead.appendChild(tr);

    tabla.appendChild(thead);

    var contenido6 = document.createElement("DIV");
    contenido6.id = 'contenedor6';

    var loader6 = document.createElement("DIV");
    loader6.id = 'loader6';
    loader6.className = 'loader';

    contenido6.appendChild(loader6);

    contenedor_idema.appendChild(tabla);
    contenedor_idema.appendChild(contenido6);
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    var boton = document.createElement("BUTTON");
    var nodoBoton = document.createTextNode("Volver");
    boton.appendChild(nodoBoton);

    boton.id = 'aceptar';
    boton.style.display = 'block';
    boton.style.margin = 'auto';
    boton.style.marginBottom = '1.5em';
    boton.style.marginTop = '1.5em';

    boton.onclick = function () {
        var caja = document.getElementById('caja');
        document.body.removeChild(caja);
        var translucido = document.getElementById('translucido');
        document.body.removeChild(translucido);
    }

    caja.appendChild(titulo);
    caja.appendChild(contenedor_idema);
    caja.appendChild(boton);


    document.body.appendChild(translucido);
    document.body.appendChild(caja);

    boton.focus();
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    var datos;
    var datosfiltrados = [];
    var lati;
    var long;
    var key = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhc2xhbmFkaWRhczk4QGdtYWlsLmNvbSIsImp0aSI6IjVmNGE3YTUyLWZjZWItNGNiZS05YzVjLTJiZDQ5OTY2ZDBhMiIsImlzcyI6IkFFTUVUIiwiaWF0IjoxNTM3ODk0NjY3LCJ1c2VySWQiOiI1ZjRhN2E1Mi1mY2ViLTRjYmUtOWM1Yy0yYmQ0OTk2NmQwYTIiLCJyb2xlIjoiIn0.-UCBvHjtvk9X-Kh-zcQ7wyk4M9yobpx1773wqb2tV6k';
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "https://opendata.aemet.es/opendata/api/observacion/convencional/datos/estacion/" + idem2 + "?api_key=" + key,
        "method": "GET",
        "headers": {
            "cache-control": "no-cache"
        }
    }
    $.ajax(settings).fail(function (response) {

        var settings2 = JSON.parse(response.responseText).datos;

        $.ajax(settings2).done(function (response) {
            var k = 0;
            datos = JSON.parse(response);
            datos.forEach(function (entry) {
                datosfiltrados[k] = entry;
                k = k + 1;
            });
            var i = 0;
            tabla = $('#dataIdema').DataTable({
                responsive: true,
                "data": datosfiltrados,
                "columns": [
                    {
                        "data": "idema"
                    },
                    {
                        "data": "ubi"
                    },
                    {
                        "data": "fint"
                    },
                    {
                        "data": "ta"
                    }
                ]

            });
            $("#loader6").fadeOut("slow");
        });
    });

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////


}

function InicializarGrid3() {
    var datos;
    var datosfiltrados = [];
    var key = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhc2xhbmFkaWRhczk4QGdtYWlsLmNvbSIsImp0aSI6IjVmNGE3YTUyLWZjZWItNGNiZS05YzVjLTJiZDQ5OTY2ZDBhMiIsImlzcyI6IkFFTUVUIiwiaWF0IjoxNTM3ODk0NjY3LCJ1c2VySWQiOiI1ZjRhN2E1Mi1mY2ViLTRjYmUtOWM1Yy0yYmQ0OTk2NmQwYTIiLCJyb2xlIjoiIn0.-UCBvHjtvk9X-Kh-zcQ7wyk4M9yobpx1773wqb2tV6k';
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "https://opendata.aemet.es/opendata/api/valores/climatologicos/inventarioestaciones/todasestaciones?api_key=" + key,
        "method": "GET",
        "headers": {
            "cache-control": "no-cache"
        }
    }
    $.ajax(settings).done(function (response) {
        var settings2 = {
            "async": true,
            "crossDomain": true,
            "url": response.datos + "?api key=" + key,
            "method": "GET",
            "headers": {
                "cache-control": "no-cache"
            }
        }
        $.ajax(settings2).done(function (response) {
            var k = 0;
            datos = JSON.parse(response);
            datos.forEach(function (entry) {
                datosfiltrados[k] = entry;
                k = k + 1;
            });
            console.log(datosfiltrados);
            console.log(datosfiltrados[5]);
            var i = 0;
            tabla = $('#dataGrid3').DataTable({
                responsive: true,
                "data": datosfiltrados,
                "columns": [
                    {
                        "data": "nombre"
                    },
                    {
                        "data": "indicativo"
                    },
                    {
                        "defaultContent": "<button onclick='imprimirIdema(this)'>Acceder</button>"
                    }
                ]

            });
            $("#loader4").fadeOut("slow");
        });
    });

}
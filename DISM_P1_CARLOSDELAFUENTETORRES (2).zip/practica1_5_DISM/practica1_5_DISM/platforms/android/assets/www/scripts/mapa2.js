﻿$(document).on("pagecreate", "#mapa", function (event) {
    GetMap();
});

function GetMap() {
    console.log("entramos ala funcion");
    var map = new Microsoft.Maps.Map('#myMap', {
        credentials: 'AgtwDG8Wn1X-qDVMkhqYuDHp9yvg1VLpAqwRM2mVdomu6tIkukTPHtdzG0UVOMlL'
    });
    //Request the user's location
    navigator.geolocation.getCurrentPosition(function (position) {
        var loc = new Microsoft.Maps.Location(
            position.coords.latitude,
            position.coords.longitude);
        //Add a pushpin at the user's location.
        var pushpin = new Microsoft.Maps.Pushpin(loc, {
            icon: 'https://www.bingmapsportal.com/Content/images/poi_custom.png',
            anchor: new Microsoft.Maps.Point(12, 39)
        });
        map.entities.push(pushpin);
        //Center the map on the user's location.
        map.setView({ center: loc, zoom: 15 });
    });
}
